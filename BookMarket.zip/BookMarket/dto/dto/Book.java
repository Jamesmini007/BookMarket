
package dto;

import java.io.Serializable;

public class Book implements Serializable{
		
		private static final long serialVersionUID = -4274700572038677000L;
	
		private String bookId;
		private String name;
		private int unitPrice;
		private String author;
		private String description;
		private String publisher;
		private String Category;
		private long UnitsInStock;
		private String ReleaseDate;
		private String Condition;
		
		private int  quantity;
		public int getQuantity() {
			return quantity;
		}
		
		public void setQuantity(int quantity) {
			this.quantity =quantity;
		}
	
		
		public Book() {
			super();
		}
		
		public Book(String bookId, String name, Integer unitPrice) {
			this.bookId = bookId;
			this.name = name;
			this.unitPrice = unitPrice;
		}
		
		public String getBookId() {
			return bookId;
		}
		public void setBookId(String bookId) {
			this.bookId = bookId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getUnitPrice() {
			return unitPrice;
		}
		public void setUnitPrice(int unitPrice) {
			this.unitPrice = unitPrice;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getPublisher() {
			return publisher;
		}
		public void setPublisher(String publisher) {
			this.publisher = publisher;
		}
		public String getCategory() {
			return Category;
		}
		public void setCategory(String category) {
			Category = category;
		}
		public long getUnitsInStock() {
			return UnitsInStock;
		}
		public void setUnitsInStock(long unitsInStock) {
			UnitsInStock = unitsInStock;
		}
		public String getReleaseDate() {
			return ReleaseDate;
		}
		public void setReleaseDate(String releaseDate) {
			ReleaseDate = releaseDate;
		}
		public String getCondition() {
			return Condition;
		}
		public void setCondition(String condition) {
			Condition = condition;
		}
		
		
		
}